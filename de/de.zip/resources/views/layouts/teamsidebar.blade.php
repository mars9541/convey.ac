<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">

    <div class="sidebar-inner slimscrollleft">
        <div id="sidebar-menu">
            <ul>
                <li class="menu-title">Main</li>
                <li><a href="{{route('team.home')}}" class="waves-effect"><i class="mdi mdi-home-variant"></i><span> Home </span></a></li>
                <li><a href="{{route('team.country')}}" class="waves-effect"><i class="mdi mdi-fingerprint"></i><span> Login to Country </span></a></li>
                <li><a href="{{route('team.inbox')}}" class="waves-effect"><i class="mdi mdi-inbox"></i><span> Inbox </span></a></li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->