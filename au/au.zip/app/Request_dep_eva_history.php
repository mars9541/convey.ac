<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Request_dep_eva_history extends Model
{
    protected $table = 'request_dep_eva_history';
    protected $keyType = 'String';
}
