<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">

    <div class="sidebar-inner slimscrollleft">
        <div id="sidebar-menu">
            <ul>
                <li class="menu-title">Main</li>
                <li><a href="{{url('citizen/home')}}" class="waves-effect"><i class="mdi mdi-home-variant"></i><span> Home </span></a></li>
                <li><a href="{{url('citizen/settings')}}" class="waves-effect"><i class="mdi mdi-settings"></i><span> Settings </span></a></li>

                <li class="menu-title"></li>
                <li><a href="{{url('citizen/last-record')}}" class="waves-effect"><i class="mdi mdi-code-array"></i><span> Last Record </span></a></li>
                <li><a href="{{url('citizen/record_list')}}" class="waves-effect"><i class="mdi mdi-view-list"></i><span> Record List </span></a></li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->
