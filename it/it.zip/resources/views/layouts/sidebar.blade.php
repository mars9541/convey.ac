<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">

    <div class="sidebar-inner slimscrollleft">
        <div id="sidebar-menu">
            <ul>

                <li class="menu-title">Main</li>

                <li>
                    <a href="{{route('global.home')}}" class="waves-effect"><i class="mdi mdi-home-variant"></i><span> Home </span></a>
                </li>

                <li>
                    <a href="{{route('global.country')}}" class="waves-effect"><i class="mdi mdi-format-list-bulleted-type"></i><span> Country List </span></a>
                </li>
                <li>
                    <a href="{{route('global.department')}}" class="waves-effect"><i class="mdi mdi-format-list-bulleted-type"></i><span> Department List </span></a>
                </li>

                <li>
                    <a href="{{route('global.members')}}" class="waves-effect"><i class="mdi mdi-account-multiple-plus"></i><span> Team Members </span></a>
                </li>


            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->