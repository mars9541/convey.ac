<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class TestData extends Model
{
    protected $table = 'y_test_data';
}
