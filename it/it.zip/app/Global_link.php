<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Global_link extends Model
{
	protected $connection = 'mysql2';
    protected $table = 'global_link';
}
