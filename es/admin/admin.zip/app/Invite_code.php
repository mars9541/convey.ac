<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Invite_code extends Model
{
    protected $table = 'n_generated_invite_codes';
}
