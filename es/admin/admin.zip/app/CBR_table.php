<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class CBR_table extends Model
{
	
    protected $table = 'e_cbr_table';
    protected $keyType = 'String';

}
