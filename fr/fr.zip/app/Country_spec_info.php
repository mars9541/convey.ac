<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Country_spec_info extends Model
{
    protected $table = 'b_country_spec_info';
}
