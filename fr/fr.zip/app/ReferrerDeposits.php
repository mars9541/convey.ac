<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ReferrerDeposits extends Model
{

    protected $table = 'p_referrer_deposits';


}
