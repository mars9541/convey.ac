<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class Cohort extends Model
{
	
    protected $table = 'k_cohort';
    protected $keyType = 'String';
}
