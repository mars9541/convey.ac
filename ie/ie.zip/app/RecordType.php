<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class RecordType extends Model
{
	
    protected $table = 'i_direct_connect_record_type';
    protected $keyType = 'String';
}
