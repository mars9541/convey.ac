<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class RDB extends Model
{
	
    protected $table = 'l_record_databank_temp';
    protected $keyType = 'String';
}
