<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class Article extends Model
{
	
    protected $table = 'u_article';
    protected $keyType = 'String';

}
