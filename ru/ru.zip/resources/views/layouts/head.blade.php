<!-- App Icons -->
<link rel="shortcut icon" href="{{ asset('front/images/favicon.png') }}">
        
@yield('css')

<!-- Basic Css files -->
<link href="{{ asset('plugins/select2/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('plugins/sweet-alert2/sweetalert2.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('plugins/chartist/css/chartist.min.css') }} " rel="stylesheet" type="text/css">
<link href="{{ asset('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css') }}" rel="stylesheet">
<link href="{{ asset('plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css') }}" rel="stylesheet">
<link href="{{ asset('plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css') }}" rel="stylesheet" />
<link href="{{ asset('plugins/datatables/dataTables.bootstrap4.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('plugins/alertify/css/alertify.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('plugins/summernote/summernote-bs4.css') }}" rel="stylesheet" />

        <!--Chartist Chart CSS -->
<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('assets/css/icons.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('assets/css/style.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('assets/css/convey.css')}}" rel="stylesheet" type="text/css">