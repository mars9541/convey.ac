<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Replacement_number_table extends Model
{
    protected $table = 'd_replacement_search_number_history';
    protected $keyType = 'String';
}
