<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class Guide extends Model
{
	
    protected $table = 't_guide';
    protected $keyType = 'String';
}
