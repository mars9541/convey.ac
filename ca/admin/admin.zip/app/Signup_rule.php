<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Signup_rule extends Model
{
    protected $table = 's_signup_rules';
}
