<link rel="shortcut icon" href="{{ asset('front/images/favicon.png') }}">

<div class="about-business-2x">
    <div class="container">
        <div class="about-business-content-2x">
            <div class="row">
                <div class="col-md-8">
                    <div class="about-business-right-2x mb-3 py-3">
                        <img class="img-responsive" src="{{asset('landing_front')}}/images/example_landing_page.jpg" alt="sample image" width="100%">
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>


