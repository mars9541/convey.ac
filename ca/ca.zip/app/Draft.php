<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class Draft extends Model
{

    protected $table = 'l_record_draft_table';

}
