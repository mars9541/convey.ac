<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Openticket extends Model
{
	protected $connection = 'mysql2';
    protected $table = 'openticket';

}
