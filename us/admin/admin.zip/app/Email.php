<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class Email extends Model
{
    protected $table = 'x_email_template';
}
