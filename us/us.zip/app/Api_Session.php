<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Api_Session extends Model
{
    protected $table = 'r_api_sessions';
}
