<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
class Employees extends Model
{
	
    protected $table = 'h_direct_connect_employee';
    protected $keyType = 'String';

    
}
