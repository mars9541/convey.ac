<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Main_model;
// use App\Employees;
class RecordHistory extends Model
{
	
    protected $table = 'j_direct_connect_record_history';
    protected $keyType = 'String';
   
}
